﻿namespace App_servizio_pasticceria // Namespace dell'applicazione
{
    partial class Form1 // Definizione parziale della classe Form1
    {
        /// <summary>
        /// Variabile contenitore dei componenti della finestra
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Metodo per liberare le risorse utilizzate
        /// </summary>
        /// <param name="disposing">
        /// true = libera le risorse gestite
        /// false = non libera le risorse gestite
        /// </param>
        protected override void Dispose(bool disposing) // Override del metodo Dispose
        {
            if (disposing && (components != null)) // Controlla se eliminare i componenti
            {
                components.Dispose(); // Libera i componenti
            }

            base.Dispose(disposing); // Richiama il Dispose della classe base
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Metodo generato automaticamente dal designer
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textOrdine = new TextBox();
            textDispensa = new TextBox();
            textRicetta = new TextBox();
            textSpesa = new TextBox();
            btnCompra = new Button();
            btnCucina = new Button();
            SuspendLayout();

            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe Print", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.HotPink;
            label1.Location = new Point(77, 55);
            label1.Name = "label1";
            label1.Size = new Size(122, 43);
            label1.TabIndex = 0;
            label1.Text = "ORDINE";

            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe Print", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.HotPink;
            label2.Location = new Point(353, 55);
            label2.Name = "label2";
            label2.Size = new Size(132, 43);
            label2.TabIndex = 1;
            label2.Text = "RICETTA";

            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe Print", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.HotPink;
            label3.Location = new Point(610, 55);
            label3.Name = "label3";
            label3.Size = new Size(153, 43);
            label3.TabIndex = 2;
            label3.Text = "DISPENSA";

            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe Print", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.HotPink;
            label4.Location = new Point(864, 55);
            label4.Name = "label4";
            label4.Size = new Size(191, 43);
            label4.TabIndex = 3;
            label4.Text = "LISTA SPESA";

            // 
            // textOrdine
            // 
            textOrdine.BackColor = Color.MistyRose;
            textOrdine.ForeColor = SystemColors.MenuText;
            textOrdine.Location = new Point(39, 156);
            textOrdine.Margin = new Padding(3, 4, 3, 4);
            textOrdine.Multiline = true;
            textOrdine.Name = "textOrdine";
            textOrdine.ScrollBars = ScrollBars.Vertical;
            textOrdine.Size = new Size(243, 342);
            textOrdine.TabIndex = 4;

            // 
            // textDispensa
            // 
            textDispensa.BackColor = Color.MistyRose;
            textDispensa.Location = new Point(581, 156);
            textDispensa.Margin = new Padding(3, 4, 3, 4);
            textDispensa.Multiline = true;
            textDispensa.Name = "textDispensa";
            textDispensa.ScrollBars = ScrollBars.Vertical;
            textDispensa.Size = new Size(235, 342);
            textDispensa.TabIndex = 5;

            // 
            // textRicetta
            // 
            textRicetta.BackColor = Color.MistyRose;
            textRicetta.Location = new Point(311, 156);
            textRicetta.Margin = new Padding(3, 4, 3, 4);
            textRicetta.Multiline = true;
            textRicetta.Name = "textRicetta";
            textRicetta.ScrollBars = ScrollBars.Vertical;
            textRicetta.Size = new Size(236, 342);
            textRicetta.TabIndex = 6;

            // 
            // textSpesa
            // 
            textSpesa.BackColor = Color.MistyRose;
            textSpesa.Location = new Point(850, 156);
            textSpesa.Margin = new Padding(3, 4, 3, 4);
            textSpesa.Multiline = true;
            textSpesa.Name = "textSpesa";
            textSpesa.ScrollBars = ScrollBars.Vertical;
            textSpesa.Size = new Size(246, 342);
            textSpesa.TabIndex = 7;

            // 
            // btnCompra
            // 
            btnCompra.BackColor = Color.LightPink;
            btnCompra.FlatStyle = FlatStyle.Flat;
            btnCompra.Font = new Font("Segoe Script", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCompra.ForeColor = Color.White;
            btnCompra.Location = new Point(895, 520);
            btnCompra.Name = "btnCompra";
            btnCompra.Size = new Size(136, 40);
            btnCompra.TabIndex = 8;
            btnCompra.Text = "Compra";
            btnCompra.UseVisualStyleBackColor = false;
            btnCompra.Click += btnCompra_Click;

            // 
            // btnCucina
            // 
            btnCucina.BackColor = Color.DeepPink;
            btnCucina.FlatStyle = FlatStyle.Flat;
            btnCucina.Font = new Font("Segoe Script", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCucina.ForeColor = Color.White;
            btnCucina.Location = new Point(500, 664);
            btnCucina.Name = "btnCucina";
            btnCucina.Size = new Size(170, 57);
            btnCucina.TabIndex = 9;
            btnCucina.Text = "Cucina";
            btnCucina.UseVisualStyleBackColor = false;
            btnCucina.Click += btnCucina_Click;

            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LavenderBlush;
            ClientSize = new Size(1304, 744);
            Controls.Add(btnCucina);
            Controls.Add(btnCompra);
            Controls.Add(textSpesa);
            Controls.Add(textRicetta);
            Controls.Add(textDispensa);
            Controls.Add(textOrdine);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1; // Dichiarazione label1
        private Label label2; // Dichiarazione label2
        private Label label3; // Dichiarazione label3
        private Label label4; // Dichiarazione label4

        private TextBox textOrdine; // Dichiarazione textbox ordine
        private TextBox textDispensa; // Dichiarazione textbox dispensa
        private TextBox textRicetta; // Dichiarazione textbox ricetta
        private TextBox textSpesa; // Dichiarazione textbox spesa

        private Button btnCompra; // Dichiarazione pulsante compra
        private Button btnCucina; // Dichiarazione pulsante cucina
    }
}