﻿using System; // Libreria principale di C#
using System.Collections.Generic; // Libreria per liste e dizionari
using System.IO; // Libreria per gestione file/cartelle
using System.Linq; // Libreria per query LINQ
using System.Windows.Forms; // Libreria Windows Forms

namespace App_servizio_pasticceria // Namespace del progetto
{
    public partial class Form1 : Form // Classe principale della finestra
    {
        FileSystemWatcher watcher; // Oggetto che controlla modifiche ai file

        // =========================
        // LIBRO RICETTE
        // =========================

        // Dizionario contenente:
        // chiave = nome dolce
        // valore = descrizione completa della ricetta
        Dictionary<string, string> ricette = new Dictionary<string, string>()
        {
            // Ricetta tiramisu
            { "tiramisù", "Tiramisù. Ingredienti: zucchero, uova, biscotti, mascarpone, caffe." +
                " Preparazione: Prepara una crema con mascarpone, uova e zucchero. Inzuppa i savoiardi" +
                " nel caffè e crea degli strati alternando biscotti e crema. Completa con cacao amaro e " +
                "lascia riposare in frigorifero." },

            // Ricetta millefoglie
            { "millefoglie", "Millefoglie. Ingredienti: pasta sfoglia, crema, zucchero a velo. Preparazione: Cuoci la pasta sfoglia " +
                "fino a renderla dorata e croccante. Prepara una crema pasticcera vellutata e alterna gli strati. " +
                "Decora con zucchero a velo e frutta fresca." },

            // Ricetta cheesecake
            { "cheesecake", "Cheesecake. Ingredienti: biscotti, burro, mascarpone, zucchero, panna. Preparazione: Prepara una base di biscotti e burro compattata in una tortiera. Aggiungi una crema" +
                " di formaggio e panna. Lascia raffreddare e decora con frutta o salsa dolce." },

            // Ricetta cookies
            { "cookies", "Cookie. Ingredienti: farina, zucchero, burro, cioccolato, uova. Preparazione: Mescola burro, zucchero, uova e farina fino ad " +
                "ottenere un impasto morbido. Aggiungi gocce di cioccolato e forma delle palline. Cuoci in forno fino a leggera doratura." },

            // Budino alla vaniglia
            { "budino - vaniglia", "Budino Vaniglia. Ingredienti: latte, zucchero, vaniglia, amido. Preparazione: Mescola latte, zucchero e cacao o vaniglia con amido di mais. Cuoci sul fuoco fino ad ottenere " +
                "una crema densa. Versa negli stampini e lascia raffreddare in frigorifero." },

            // Budino al cioccolato
            { "budino - cioccolato", "Budino Cioccolato. Ingredienti: latte, zucchero, cioccolato, amido. Preparazione: Mescola latte, zucchero e cacao o vaniglia con amido di mais. Cuoci sul fuoco fino ad ottenere una crema densa." +
                " Versa negli stampini e lascia raffreddare in frigorifero." },

            // Cannolo
            { "cannolo", "Cannolo. Ingredienti: farina, zucchero, ricotta, cioccolato. Preparazione: Friggi le cialde fino a renderle croccanti." +
                " Prepara il ripieno mescolando ricotta zuccherata e gocce di cioccolato. Farcisci i cannoli poco prima di servirli." },

            // Croissant vuoto
            { "croissant - vuoto", "Croissant Vuoto. Ingredienti: farina, burro, latte, zucchero, lievito. Preparazione: Prepara un impasto sfogliato con burro e pieghe multiple." +
                " Forma i croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura" },

            // Croissant al cioccolato
            { "croissant - cioccolato", "Croissant Cioccolato. Ingredienti: farina, burro, latte, zucchero, lievito, cioccolato. Preparazione: Prepara un impasto sfogliato " +
                "con burro e pieghe multiple. Forma i croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura" },

            // Croissant al pistacchio
            { "croissant - pistacchio", "Croissant Pistacchio. Ingredienti: farina, burro, latte, zucchero, lievito, pistacchio. Preparazione: Prepara un impasto sfogliato con burro e pieghe multiple." +
                " Forma i croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura e aggiungere il pistacchio." },

            // Croissant alla crema
            { "croissant - crema", "Croissant Crema. Ingredienti: farina, burro, latte, zucchero, lievito, crema. Preparazione: Prepara un impasto sfogliato con burro e pieghe multiple. Forma i " +
                "croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura e aggiungi la crema." },

            // Croissant alla marmellata
            { "croissant - marmellata", "Croissant Marmellata. Ingredienti: farina, burro, latte, zucchero, lievito, marmellata. Preparazione: Prepara un impasto sfogliato con burro e pieghe multiple." +
                " Forma i croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura e aggiungere marmellata" },

            // Pancake
            { "pancake", "Pancake. Ingredienti: farina, latte, uova, zucchero, burro. Preparazione:Mescola farina, latte, uova e lievito fino ad ottenere una pastella liscia. Versa l’impasto in padella calda" +
                " e cuoci da entrambi i lati. Servi con sciroppo o frutta." },

            // Macaron fragola
            { "macaron - fragola", "Macaron Fragola. Ingredienti: mandorle, zucchero, albumi, fragola. Preparazione: Monta gli albumi con zucchero e unisci farina di mandorle e zucchero a velo. Forma piccoli dischi " +
                "e lascia riposare prima della cottura. Farcisci con crema o ganache." },

            // Macaron cioccolato
            { "macaron - cioccolato", "Macaron Cioccolato. Ingredienti: mandorle, zucchero, albumi, cioccolato. Preparazione: Monta gli albumi con zucchero e unisci farina di mandorle e zucchero a velo. Forma piccoli dischi " +
                "e lascia riposare prima della cottura. Farcisci con crema o ganache." },

            // Macaron vaniglia
            { "macaron - vaniglia", "Macaron Vaniglia. Ingredienti: mandorle, zucchero, albumi, vaniglia. Preparazione: Monta gli albumi con zucchero e unisci farina di mandorle e zucchero a velo. Forma piccoli dischi" +
                " e lascia riposare prima della cottura. Farcisci con crema o ganache." },

            // Macaron pistacchio
            { "macaron - pistacchio", "Macaron Pistacchio. Ingredienti: mandorle, zucchero, albumi, pistacchio. Preparazione: Monta gli albumi con zucchero e unisci farina di mandorle e zucchero a velo. Forma piccoli dischi " +
                "e lascia riposare prima della cottura. Farcisci con crema o ganache." },

            // Gelato fragola
            { "gelato - fragola", "Gelato Fragola. Ingredienti: latte, panna, zucchero, fragola. Preparazione: Scalda latte, panna e zucchero creando una base cremosa. Lascia raffreddare e manteca " +
                "in gelatiera o freezer. Servi ben freddo con topping a piacere." },

            // Gelato cioccolato
            { "gelato - cioccolato", "Gelato Cioccolato. Ingredienti: latte, panna, zucchero, cioccolato. Preparazione: Scalda latte, panna e zucchero creando una base cremosa. Lascia raffreddare e manteca in gelatiera" +
                " o freezer. Servi ben freddo con topping a piacere." },

            // Gelato vaniglia
            { "gelato - vaniglia", "Gelato Vaniglia. Ingredienti: latte, panna, zucchero, vaniglia. Preparazione: Scalda latte, panna e zucchero creando una base cremosa. Lascia raffreddare e manteca in gelatiera" +
                " o freezer. Servi ben freddo con topping a piacere." },

            // Gelato pistacchio
            { "gelato - pistacchio", "Gelato Pistacchio. Ingredienti: latte, panna, zucchero, pistacchio. Preparazione: Scalda latte, panna e zucchero creando una base cremosa. Lascia raffreddare e manteca in gelatiera" +
                " o freezer. Servi ben freddo con topping a piacere." }
        };

        // =========================
        // DISPENSA
        // =========================

        // Lista ingredienti disponibili nella dispensa
        List<string> dispensa = new List<string>()
        {
            "farina", // Ingrediente presente
            "burro", // Ingrediente presente
            "latte", // Ingrediente presente
            "lievito" // Ingrediente presente
        };

        // Costruttore della finestra
        public Form1()
        {
            InitializeComponent(); // Inizializza componenti grafici

            // Mostra gli ingredienti della dispensa nella textbox
            textDispensa.Text = String.Join(Environment.NewLine, dispensa);

            SetupWatcher(); // Avvia controllo file ordine
        }

        // Metodo che configura il FileSystemWatcher
        void SetupWatcher()
        {
            watcher = new FileSystemWatcher(); // Crea watcher

            // Imposta la cartella Downloads
            watcher.Path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads");

            watcher.Filter = "ordine*.txt"; // Controlla file che iniziano con ordine

            // Controlla modifiche nome, dimensione e scrittura file
            watcher.NotifyFilter =
                NotifyFilters.LastWrite |
                NotifyFilters.FileName |
                NotifyFilters.Size;

            watcher.Changed += OnFileChanged; // Evento modifica file
            watcher.Created += OnFileChanged; // Evento creazione file

            watcher.EnableRaisingEvents = true; // Attiva watcher
        }

        // Metodo eseguito quando cambia un file
        void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            System.Threading.Thread.Sleep(700); // Aspetta 700 ms

            // Controlla se la finestra esiste
            if (this.IsHandleCreated)
            {
                // Esegue caricamento ordine nel thread grafico
                this.BeginInvoke(new Action(() => CaricaOrdine()));
            }
        }

        // =========================
        // LEGGE ORDINE
        // =========================

        // Metodo che legge i file ordine
        void CaricaOrdine()
        {
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads");

            var file = new DirectoryInfo(path)
                .GetFiles("ordine*.txt")
                .OrderByDescending(f => f.LastWriteTime)
                .FirstOrDefault();

            if (file == null) return;

            try
            {
                string[] righe = File.ReadAllLines(file.FullName);

                List<string> ordiniValidi = new List<string>();

                foreach (string r in righe)
                {
                    string p = r.Trim().ToLower();
                    if (!string.IsNullOrWhiteSpace(p))
                        ordiniValidi.Add(p);
                }

                if (ordiniValidi.Count == 0) return;

                // conta quantità
                Dictionary<string, int> conteggio = new Dictionary<string, int>();
                List<string> ordineBase = new List<string>();

                foreach (string d in ordiniValidi)
                {
                    if (!conteggio.ContainsKey(d))
                    {
                        conteggio[d] = 1;
                        ordineBase.Add(d);
                    }
                    else
                        conteggio[d]++;
                }

                List<string> output = new List<string>();

                foreach (string d in ordineBase)
                {
                    int q = conteggio[d];
                    output.Add(q > 1 ? $"{d} x{q}" : d);
                }

                textOrdine.Text = String.Join(Environment.NewLine, output);

                GestisciOrdiniMultipli(ordiniValidi);
            }
            catch { }
        }

        // =========================
        // GESTIONE ORDINI MULTIPLI
        // =========================

        // Metodo che gestisce più dolci ordinati
        void GestisciOrdiniMultipli(List<string> listaDolci)
        {
            List<string> ricetteTotali = new List<string>();

            HashSet<string> dolciUnici = new HashSet<string>();
            foreach (string d in listaDolci)
            {
                dolciUnici.Add(d.Trim().ToLower());
            }

            Dictionary<string, int> fabbisognoTotale = new Dictionary<string, int>();

            foreach (string dolce in dolciUnici)
            {
                if (!ricette.ContainsKey(dolce))
                    continue;

                ricetteTotali.Add($"{dolce}");
                ricetteTotali.Add(ricette[dolce]);

                List<string> ingredienti = EstraiIngredienti(ricette[dolce]);

                foreach (string ing in ingredienti)
                {
                    string i = ing.Trim().ToLower();

                    if (!fabbisognoTotale.ContainsKey(i))
                        fabbisognoTotale[i] = 0;

                    fabbisognoTotale[i] += 1;
                }
            }

            List<string> spesa = new List<string>();

            // CORREZIONE LOGICA CONFRONTO:
            foreach (var item in fabbisognoTotale)
            {
                string ingrediente = item.Key;
                int richiesto = item.Value;

                // Conta quanti ce ne sono realmente in dispensa
                int disponibili = dispensa.Count(x => x.ToLower() == ingrediente);

                int mancano = richiesto - disponibili;

                // Se mancano pezzi rispetto a quanti ne abbiamo in dispensa, inseriscili nella spesa
                for (int i = 0; i < mancano; i++)
                {
                    spesa.Add(ingrediente);
                }
            }

            textRicetta.Text =
                String.Join(Environment.NewLine + "---" + Environment.NewLine, ricetteTotali);

            textSpesa.Text =
                String.Join(Environment.NewLine, spesa);
        }

        // =========================
        // ESTRAE INGREDIENTI
        // =========================

        // METODO FABBISOGNO
        Dictionary<string, int> CalcolaFabbisogno(List<string> listaDolci)
        {
            Dictionary<string, int> fabbisogno = new Dictionary<string, int>();

            foreach (string d in listaDolci)
            {
                string dolce = d.Trim().ToLower();

                if (!ricette.ContainsKey(dolce))
                    continue;

                List<string> ingredienti = EstraiIngredienti(ricette[dolce]);

                foreach (string ing in ingredienti)
                {
                    string i = ing.Trim().ToLower();

                    if (!fabbisogno.ContainsKey(i))
                        fabbisogno[i] = 0;

                    fabbisogno[i] += 1;
                }
            }

            return fabbisogno;
        }

        // Metodo che estrae ingredienti dalla stringa ricetta
        List<string> EstraiIngredienti(string ricetta)
        {
            List<string> listaFiltrata = new List<string>();

            try
            {
                string tagInizio = "Ingredienti:";
                string tagFine = "Preparazione:";

                int inizio =
                    ricetta.IndexOf(tagInizio) + tagInizio.Length;

                int fine = ricetta.IndexOf(tagFine);

                if (inizio > -1 && fine > inizio)
                {
                    string parteIngredienti =
                        ricetta.Substring(inizio, fine - inizio);

                    string[] array =
                        parteIngredienti.Split(
                            new char[] { ',', '.' },
                            StringSplitOptions.RemoveEmptyEntries);

                    foreach (string item in array)
                    {
                        string pulito =
                            item.Trim().ToLower();

                        if (!string.IsNullOrWhiteSpace(pulito))
                            listaFiltrata.Add(pulito);
                    }
                }
            }
            catch { }

            return listaFiltrata;
        }

        // Evento caricamento finestra
        private void Form1_Load(object sender, EventArgs e) { }

        // Evento click pulsante Compra
        private void btnCompra_Click(object sender, EventArgs e)
        {
            string[] ingredientiDaComprare =
                textSpesa.Text.Split(
                    new[] { Environment.NewLine },
                    StringSplitOptions.RemoveEmptyEntries);

            foreach (string ingrediente in ingredientiDaComprare)
            {
                string i = ingrediente.Trim().ToLower();
                dispensa.Add(i);
            }

            textDispensa.Text =
                String.Join(Environment.NewLine, dispensa);

            textSpesa.Clear();

            MessageBox.Show("Ingredienti acquistati!");
        }

        // Evento click pulsante Cucina
        private void btnCucina_Click(object sender, EventArgs e)
        {
            string[] righe =
                textOrdine.Text.Split(
                    new[] { Environment.NewLine },
                    StringSplitOptions.RemoveEmptyEntries);

            foreach (string riga in righe)
            {
                string dolce = riga.Trim().ToLower();

                if (riga.Contains(" x"))
                {
                    string[] parti = riga.Split(new string[] { " x" }, StringSplitOptions.None);
                    dolce = parti[0].Trim().ToLower();
                }

                if (!ricette.ContainsKey(dolce))
                    continue;

                List<string> ingredienti = EstraiIngredienti(ricette[dolce]);

                foreach (string ing in ingredienti)
                {
                    string i2 = ing.Trim().ToLower();
                    dispensa.Remove(i2);
                }
            }

            textDispensa.Text = String.Join(Environment.NewLine, dispensa);

            textOrdine.Clear();
            textRicetta.Clear();
            textSpesa.Clear();

            MessageBox.Show("Cucina completata!");
        }
    }
}