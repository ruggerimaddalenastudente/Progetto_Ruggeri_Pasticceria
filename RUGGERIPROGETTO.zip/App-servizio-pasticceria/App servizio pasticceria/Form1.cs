using System; // Libreria principale di C#
using System.Collections.Generic; // Libreria per liste e dizionari
using System.IO; // Libreria per gestione file/cartelle
using System.Linq; // Libreria per query LINQ
using System.Windows.Forms; // Libreria Windows Forms

namespace App_servizio_pasticceria // Namespace del progetto
{
    public partial class Form1 : Form // Classe principale della finestra
    {
        FileSystemWatcher watcher; // Oggetto che controlla modifiche ai file

        // =========================
        // LIBRO RICETTE
        // =========================

        // Dizionario contenente:
        // chiave = nome dolce
        // valore = descrizione completa della ricetta
        Dictionary<string, string> ricette = new Dictionary<string, string>()
        {
            // Ricetta tiramisu
            { "tiramisu", "Tiramisu. Ingredienti: zucchero, uova, biscotti, mascarpone, caffe." +
                " Preparazione: Prepara una crema con mascarpone, uova e zucchero. Inzuppa i savoiardi" +
                " nel caff� e crea degli strati alternando biscotti e crema. Completa con cacao amaro e " +
                "lascia riposare in frigorifero." },

            // Ricetta millefoglie
            { "millefoglie", "Millefoglie. Ingredienti: pasta sfoglia, crema, zucchero a velo. Preparazione: Cuoci la pasta sfoglia " +
                "fino a renderla dorata e croccante. Prepara una crema pasticcera vellutata e alterna gli strati. " +
                "Decora con zucchero a velo e frutta fresca." },

            // Ricetta cheesecake
            { "cheesecake", "Cheesecake. Ingredienti: biscotti, burro, mascarpone, zucchero, panna. Preparazione: Prepara una base di biscotti e burro compattata in una tortiera. Aggiungi una crema" +
                " di formaggio e panna. Lascia raffreddare e decora con frutta o salsa dolce." },

            // Ricetta cookies
            { "cookies", "Cookie. Ingredienti: farina, zucchero, burro, cioccolato, uova. Preparazione: Mescola burro, zucchero, uova e farina fino ad " +
                "ottenere un impasto morbido. Aggiungi gocce di cioccolato e forma delle palline. Cuoci in forno fino a leggera doratura." },

            // Budino alla vaniglia
            { "budino - vaniglia", "Budino Vaniglia. Ingredienti: latte, zucchero, vaniglia, amido. Preparazione: Mescola latte, zucchero e cacao o vaniglia con amido di mais. Cuoci sul fuoco fino ad ottenere " +
                "una crema densa. Versa negli stampini e lascia raffreddare in frigorifero." },

            // Budino al cioccolato
            { "budino - cioccolato", "Budino Cioccolato. Ingredienti: latte, zucchero, cioccolato, amido. Preparazione: Mescola latte, zucchero e cacao o vaniglia con amido di mais. Cuoci sul fuoco fino ad ottenere una crema densa." +
                " Versa negli stampini e lascia raffreddare in frigorifero." },

            // Cannolo
            { "cannolo", "Cannolo. Ingredienti: farina, zucchero, ricotta, cioccolato. Preparazione: Friggi le cialde fino a renderle croccanti." +
                " Prepara il ripieno mescolando ricotta zuccherata e gocce di cioccolato. Farcisci i cannoli poco prima di servirli." },

            // Croissant vuoto
            { "croissant - vuoto", "Croissant Vuoto. Ingredienti: farina, burro, latte, zucchero, lievito. Preparazione: Prepara un impasto sfogliato con burro e pieghe multiple." +
                " Forma i croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura" },

            // Croissant al cioccolato
            { "croissant - cioccolato", "Croissant Cioccolato. Ingredienti: farina, burro, latte, zucchero, lievito, cioccolato. Preparazione: Prepara un impasto sfogliato " +
                "con burro e pieghe multiple. Forma i croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura" },

            // Croissant al pistacchio
            { "croissant - pistacchio", "Croissant Pistacchio. Ingredienti: farina, burro, latte, zucchero, lievito, pistacchio. Preparazione: Prepara un impasto sfogliato con burro e pieghe multiple." +
                " Forma i croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura e aggiungere il pistacchio." },

            // Croissant alla crema
            { "croissant - crema", "Croissant Crema. Ingredienti: farina, burro, latte, zucchero, lievito, crema. Preparazione: Prepara un impasto sfogliato con burro e pieghe multiple. Forma i " +
                "croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura e aggiungi la crema." },

            // Croissant alla marmellata
            { "croissant - marmellata", "Croissant Marmellata. Ingredienti: farina, burro, latte, zucchero, lievito, marmellata. Preparazione: Prepara un impasto sfogliato con burro e pieghe multiple." +
                " Forma i croissant arrotolando i triangoli di pasta. Lascia lievitare e cuoci fino a doratura e aggiungere marmellata" },

            // Pancake
            { "pancake", "Pancake. Ingredienti: farina, latte, uova, zucchero, burro. Preparazione:Mescola farina, latte, uova e lievito fino ad ottenere una pastella liscia. Versa l�impasto in padella calda" +
                " e cuoci da entrambi i lati. Servi con sciroppo o frutta." },

            // Macaron fragola
            { "macaron - fragola", "Macaron Fragola. Ingredienti: mandorle, zucchero, albumi, fragola. Preparazione: Monta gli albumi con zucchero e unisci farina di mandorle e zucchero a velo. Forma piccoli dischi " +
                "e lascia riposare prima della cottura. Farcisci con crema o ganache." },

            // Macaron cioccolato
            { "macaron - cioccolato", "Macaron Cioccolato. Ingredienti: mandorle, zucchero, albumi, cioccolato. Preparazione: Monta gli albumi con zucchero e unisci farina di mandorle e zucchero a velo. Forma piccoli dischi " +
                "e lascia riposare prima della cottura. Farcisci con crema o ganache." },

            // Macaron vaniglia
            { "macaron - vaniglia", "Macaron Vaniglia. Ingredienti: mandorle, zucchero, albumi, vaniglia. Preparazione: Monta gli albumi con zucchero e unisci farina di mandorle e zucchero a velo. Forma piccoli dischi" +
                " e lascia riposare prima della cottura. Farcisci con crema o ganache." },

            // Macaron pistacchio
            { "macaron - pistacchio", "Macaron Pistacchio. Ingredienti: mandorle, zucchero, albumi, pistacchio. Preparazione: Monta gli albumi con zucchero e unisci farina di mandorle e zucchero a velo. Forma piccoli dischi " +
                "e lascia riposare prima della cottura. Farcisci con crema o ganache." },

            // Gelato fragola
            { "gelato - fragola", "Gelato Fragola. Ingredienti: latte, panna, zucchero, fragola. Preparazione: Scalda latte, panna e zucchero creando una base cremosa. Lascia raffreddare e manteca " +
                "in gelatiera o freezer. Servi ben freddo con topping a piacere." },

            // Gelato cioccolato
            { "gelato - cioccolato", "Gelato Cioccolato. Ingredienti: latte, panna, zucchero, cioccolato. Preparazione: Scalda latte, panna e zucchero creando una base cremosa. Lascia raffreddare e manteca in gelatiera" +
                " o freezer. Servi ben freddo con topping a piacere." },

            // Gelato vaniglia
            { "gelato - vaniglia", "Gelato Vaniglia. Ingredienti: latte, panna, zucchero, vaniglia. Preparazione: Scalda latte, panna e zucchero creando una base cremosa. Lascia raffreddare e manteca in gelatiera" +
                " o freezer. Servi ben freddo con topping a piacere." },

            // Gelato pistacchio
            { "gelato - pistacchio", "Gelato Pistacchio. Ingredienti: latte, panna, zucchero, pistacchio. Preparazione: Scalda latte, panna e zucchero creando una base cremosa. Lascia raffreddare e manteca in gelatiera" +
                " o freezer. Servi ben freddo con topping a piacere." }
        };

        // =========================
        // DISPENSA
        // =========================

        // Lista ingredienti disponibili nella dispensa
        List<string> dispensa = new List<string>()
        {
            "farina", // Ingrediente presente
            "zucchero", // Ingrediente presente
            "burro", // Ingrediente presente
            "latte", // Ingrediente presente
            "lievito" // Ingrediente presente
        };

        // Costruttore della finestra
        public Form1()
        {
            InitializeComponent(); // Inizializza componenti grafici

            // Mostra gli ingredienti della dispensa nella textbox
            textDispensa.Text = String.Join(Environment.NewLine, dispensa);

            SetupWatcher(); // Avvia controllo file ordine
        }

        // Metodo che configura il FileSystemWatcher
        void SetupWatcher()
        {
            watcher = new FileSystemWatcher(); // Crea watcher

            // Imposta la cartella Downloads
            watcher.Path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads");

            watcher.Filter = "ordine*.txt"; // Controlla file che iniziano con ordine

            // Controlla modifiche nome, dimensione e scrittura file
            watcher.NotifyFilter =
                NotifyFilters.LastWrite |
                NotifyFilters.FileName |
                NotifyFilters.Size;

            watcher.Changed += OnFileChanged; // Evento modifica file
            watcher.Created += OnFileChanged; // Evento creazione file

            watcher.EnableRaisingEvents = true; // Attiva watcher
        }

        // Metodo eseguito quando cambia un file
        void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            System.Threading.Thread.Sleep(700); // Aspetta 700 ms

            // Controlla se la finestra esiste
            if (this.IsHandleCreated)
            {
                // Esegue caricamento ordine nel thread grafico
                this.BeginInvoke(new Action(() => CaricaOrdine()));
            }
        }

        // =========================
        // LEGGE ORDINE
        // =========================

        // Metodo che legge i file ordine
        void CaricaOrdine()
        {
            // Percorso Downloads
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "Downloads");

            // Cerca il file ordine pi� recente
            var file = new DirectoryInfo(path)
                .GetFiles("ordine*.txt")
                .OrderByDescending(f => f.LastWriteTime)
                .FirstOrDefault();

            // Controlla se il file esiste
            if (file != null)
            {
                try
                {
                    // Legge tutte le righe del file
                    string[] righe = File.ReadAllLines(file.FullName);

                    // Lista ordini validi
                    List<string> ordiniValidi = new List<string>();

                    // Scorre ogni riga
                    foreach (string riga in righe)
                    {
                        // Rimuove spazi e converte in minuscolo
                        string pulita = riga.Trim().ToLower();

                        // Controlla che la riga non sia vuota
                        if (!string.IsNullOrWhiteSpace(pulita))
                        {
                            ordiniValidi.Add(pulita); // Aggiunge ordine
                        }
                    }

                    // Controlla se esistono ordini
                    if (ordiniValidi.Count > 0)
                    {
                        // Mostra ordini nella textbox
                        textOrdine.Text =
                            String.Join(Environment.NewLine, ordiniValidi);

                        // Gestisce ordini multipli
                        GestisciOrdiniMultipli(ordiniValidi);
                    }
                }
                catch (IOException) { } // Ignora errori file
            }
        }

        // =========================
        // GESTIONE ORDINI MULTIPLI
        // =========================

        // Metodo che gestisce pi� dolci ordinati
        void GestisciOrdiniMultipli(List<string> listaDolci)
        {
            List<string> ricetteTotali = new List<string>(); // Lista ricette
            List<string> spesaTotale = new List<string>(); // Lista spesa

            // Scorre tutti i dolci ordinati
            foreach (string dolce in listaDolci)
            {
                // Controlla se il dolce esiste nel dizionario
                if (ricette.ContainsKey(dolce))
                {
                    // Ottiene la ricetta
                    string ricettaCorrente = ricette[dolce];

                    // Aggiunge ricetta alla lista
                    ricetteTotali.Add(ricettaCorrente);

                    // Estrae ingredienti
                    List<string> ingredienti =
                        EstraiIngredienti(ricettaCorrente);

                    // Controlla ingredienti
                    foreach (string ing in ingredienti)
                    {
                        // Verifica se ingrediente manca in dispensa
                        if (!dispensa.Any(d =>
                            d.ToLower() == ing.ToLower()))
                        {
                            spesaTotale.Add(ing); // Aggiunge alla spesa
                        }
                    }
                }
                else
                {
                    // Messaggio se il dolce non esiste
                    ricetteTotali.Add(
                        $"Dolce '{dolce}' non trovato in archivio.");
                }
            }

            // Mostra tutte le ricette
            textRicetta.Text =
                String.Join(
                    Environment.NewLine + "---" + Environment.NewLine,
                    ricetteTotali);

            // Mostra lista spesa senza duplicati
            textSpesa.Text =
                String.Join(
                    Environment.NewLine,
                    spesaTotale.Distinct());
        }

        // =========================
        // ESTRAE INGREDIENTI
        // =========================

        // Metodo che estrae ingredienti dalla stringa ricetta
        List<string> EstraiIngredienti(string ricetta)
        {
            List<string> listaFiltrata = new List<string>(); // Lista finale

            try
            {
                string tagInizio = "Ingredienti:"; // Inizio ingredienti
                string tagFine = "Preparazione:"; // Fine ingredienti

                // Trova posizione inizio ingredienti
                int inizio =
                    ricetta.IndexOf(tagInizio) + tagInizio.Length;

                // Trova posizione preparazione
                int fine = ricetta.IndexOf(tagFine);

                // Controlla validit� posizioni
                if (inizio > -1 && fine > inizio)
                {
                    // Estrae parte ingredienti
                    string parteIngredienti =
                        ricetta.Substring(inizio, fine - inizio);

                    // Divide ingredienti usando virgola e punto
                    string[] array =
                        parteIngredienti.Split(
                            new char[] { ',', '.' },
                            StringSplitOptions.RemoveEmptyEntries);

                    // Scorre ingredienti
                    foreach (string item in array)
                    {
                        // Pulisce testo
                        string pulito =
                            item.Trim().ToLower();

                        // Controlla se non vuoto
                        if (!string.IsNullOrWhiteSpace(pulito))
                            listaFiltrata.Add(pulito); // Aggiunge ingrediente
                    }
                }
            }
            catch { } // Ignora errori

            return listaFiltrata; // Restituisce lista ingredienti
        }

        // Evento caricamento finestra
        private void Form1_Load(object sender, EventArgs e) { }

        // Evento click pulsante Compra
        private void btnCompra_Click(object sender, EventArgs e)
        {
            // Divide ingredienti della lista spesa
            string[] ingredientiDaComprare =
                textSpesa.Text.Split(
                    new[] { Environment.NewLine },
                    StringSplitOptions.RemoveEmptyEntries);

            // Scorre ingredienti
            foreach (string ingrediente in ingredientiDaComprare)
            {
                // Controlla se gi� presente
                if (!dispensa.Contains(ingrediente))
                {
                    dispensa.Add(ingrediente); // Aggiunge ingrediente
                }
            }

            // Aggiorna textbox dispensa
            textDispensa.Text =
                String.Join(Environment.NewLine, dispensa);

            // Svuota textbox spesa
            textSpesa.Clear();

            // Mostra messaggio
            MessageBox.Show("Ingredienti acquistati!");
        }

        // Evento click pulsante Cucina
        private void btnCucina_Click(object sender, EventArgs e)
        {
            // Svuota textbox ordine
            textOrdine.Clear();

            // Svuota textbox ricetta
            textRicetta.Clear();

            // Svuota textbox spesa
            textSpesa.Clear();

            // Mostra popup
            MessageBox.Show("L'ordine � in preparazione!");
        }
    }
}