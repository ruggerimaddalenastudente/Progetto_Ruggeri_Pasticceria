﻿using System; // Libreria base del linguaggio C#
using System.Collections.Generic; // Permette di usare liste e collezioni generiche
using System.Linq; // Libreria per query LINQ (non usata direttamente qui ma utile nel progetto)
using System.Text; // Libreria per gestione testo avanzata (non utilizzata in questa classe)
using System.Threading.Tasks; // Libreria per programmazione asincrona (non utilizzata qui)

// using System.Collections.Generic; // DUPLICATO -> inutile perché già importato sopra

namespace App_servizio_pasticceria // Namespace del progetto
{
    public class Ricetta // Classe che rappresenta una ricetta
    {
        public string Nome { get; set; } // Proprietà: nome della ricetta (es. tiramisù)
        public List<string> Ingredienti { get; set; } // Lista ingredienti della ricetta

        // Costruttore della classe Ricetta
        public Ricetta(string nome, List<string> ingredienti)
        {
            Nome = nome; // Assegna il nome passato al costruttore
            Ingredienti = ingredienti; // Assegna la lista ingredienti
        }
    }
}