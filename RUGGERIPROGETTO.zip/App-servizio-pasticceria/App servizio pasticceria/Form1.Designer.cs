﻿namespace App_servizio_pasticceria // Namespace dell'applicazione
{
    partial class Form1 // Definizione parziale della classe Form1
    {
        /// <summary>
        /// Variabile contenitore dei componenti della finestra
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Metodo per liberare le risorse utilizzate
        /// </summary>
        /// <param name="disposing">
        /// true = libera le risorse gestite
        /// false = non libera le risorse gestite
        /// </param>
        protected override void Dispose(bool disposing) // Override del metodo Dispose
        {
            if (disposing && (components != null)) // Controlla se eliminare i componenti
            {
                components.Dispose(); // Libera i componenti
            }

            base.Dispose(disposing); // Richiama il Dispose della classe base
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Metodo generato automaticamente dal designer
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label(); // Creazione label1
            label2 = new Label(); // Creazione label2
            label3 = new Label(); // Creazione label3
            label4 = new Label(); // Creazione label4

            textOrdine = new TextBox(); // Creazione textbox ordine
            textDispensa = new TextBox(); // Creazione textbox dispensa
            textRicetta = new TextBox(); // Creazione textbox ricetta
            textSpesa = new TextBox(); // Creazione textbox lista spesa

            btnCompra = new Button(); // Creazione pulsante compra
            btnCucina = new Button(); // Creazione pulsante cucina

            SuspendLayout(); // Blocca temporaneamente il layout

            // label1
            label1.AutoSize = true; // Adatta automaticamente la dimensione
            label1.Font = new Font("Segoe Print", 15F, FontStyle.Regular, GraphicsUnit.Point, 0); // Imposta il font
            label1.ForeColor = Color.FromArgb(255, 128, 128); // Imposta il colore del testo
            label1.Location = new Point(77, 55); // Posizione della label
            label1.Name = "label1"; // Nome interno della label
            label1.Size = new Size(122, 43); // Dimensione della label
            label1.TabIndex = 0; // Ordine di tabulazione
            label1.Text = "ORDINE"; // Testo visualizzato

            // label2
            label2.AutoSize = true; // Adatta automaticamente la dimensione
            label2.Font = new Font("Segoe Print", 15F, FontStyle.Regular, GraphicsUnit.Point, 0); // Font
            label2.ForeColor = Color.FromArgb(255, 128, 128); // Colore testo
            label2.Location = new Point(329, 55); // Posizione
            label2.Name = "label2"; // Nome interno
            label2.Size = new Size(132, 43); // Dimensione
            label2.TabIndex = 1; // Tab index
            label2.Text = "RICETTA"; // Testo mostrato

            // label3
            label3.AutoSize = true; // Adatta automaticamente
            label3.Font = new Font("Segoe Print", 15F, FontStyle.Regular, GraphicsUnit.Point, 0); // Font
            label3.ForeColor = Color.FromArgb(255, 128, 128); // Colore
            label3.Location = new Point(581, 55); // Posizione
            label3.Name = "label3"; // Nome
            label3.Size = new Size(153, 43); // Dimensione
            label3.TabIndex = 2; // Tab index
            label3.Text = "DISPENSA"; // Testo

            // label4
            label4.AutoSize = true; // Adatta automaticamente
            label4.Font = new Font("Segoe Print", 15F, FontStyle.Regular, GraphicsUnit.Point, 0); // Font
            label4.ForeColor = Color.FromArgb(255, 128, 128); // Colore
            label4.Location = new Point(864, 55); // Posizione
            label4.Name = "label4"; // Nome
            label4.Size = new Size(191, 43); // Dimensione
            label4.TabIndex = 3; // Tab index
            label4.Text = "LISTA SPESA"; // Testo

            // textOrdine
            textOrdine.ForeColor = SystemColors.MenuText; // Colore testo
            textOrdine.Location = new Point(39, 156); // Posizione
            textOrdine.Margin = new Padding(3, 4, 3, 4); // Margini
            textOrdine.Multiline = true; // Permette più righe
            textOrdine.Name = "textOrdine"; // Nome
            textOrdine.ScrollBars = ScrollBars.Vertical; // Barra verticale
            textOrdine.Size = new Size(243, 406); // Dimensione
            textOrdine.TabIndex = 4; // Tab index

            // textDispensa
            textDispensa.Location = new Point(581, 156); // Posizione
            textDispensa.Margin = new Padding(3, 4, 3, 4); // Margini
            textDispensa.Multiline = true; // Multilinea
            textDispensa.Name = "textDispensa"; // Nome
            textDispensa.ScrollBars = ScrollBars.Vertical; // Barra verticale
            textDispensa.Size = new Size(235, 406); // Dimensione
            textDispensa.TabIndex = 5; // Tab index

            // textRicetta
            textRicetta.Location = new Point(311, 156); // Posizione
            textRicetta.Margin = new Padding(3, 4, 3, 4); // Margini
            textRicetta.Multiline = true; // Multilinea
            textRicetta.Name = "textRicetta"; // Nome
            textRicetta.ScrollBars = ScrollBars.Vertical; // Barra verticale
            textRicetta.Size = new Size(236, 406); // Dimensione
            textRicetta.TabIndex = 6; // Tab index

            // textSpesa
            textSpesa.Location = new Point(874, 156); // Posizione
            textSpesa.Margin = new Padding(3, 4, 3, 4); // Margini
            textSpesa.Multiline = true; // Multilinea
            textSpesa.Name = "textSpesa"; // Nome
            textSpesa.ScrollBars = ScrollBars.Vertical; // Barra verticale
            textSpesa.Size = new Size(246, 406); // Dimensione
            textSpesa.TabIndex = 7; // Tab index

            // btnCompra
            btnCompra.Font = new Font("Segoe Script", 12F, FontStyle.Regular, GraphicsUnit.Point, 0); // Font pulsante
            btnCompra.ForeColor = Color.Black; // Colore testo
            btnCompra.Location = new Point(919, 581); // Posizione
            btnCompra.Name = "btnCompra"; // Nome
            btnCompra.Size = new Size(136, 40); // Dimensione
            btnCompra.TabIndex = 8; // Tab index
            btnCompra.Text = "Compra"; // Testo del pulsante
            btnCompra.UseVisualStyleBackColor = false; // Disattiva stile standard

            btnCompra.Click += btnCompra_Click; // Evento click pulsante compra

            // btnCucina
            btnCucina.Font = new Font("Segoe Script", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0); // Font
            btnCucina.Location = new Point(500, 664); // Posizione
            btnCucina.Name = "btnCucina"; // Nome
            btnCucina.Size = new Size(170, 57); // Dimensione
            btnCucina.TabIndex = 9; // Tab index
            btnCucina.Text = "Cucina"; // Testo
            btnCucina.UseVisualStyleBackColor = false; // Disattiva stile standard

            btnCucina.Click += btnCucina_Click; // Evento click pulsante cucina

            // Form1
            AutoScaleDimensions = new SizeF(8F, 20F); // Scala automatica
            AutoScaleMode = AutoScaleMode.Font; // Modalità scala font

            ClientSize = new Size(1304, 744); // Dimensioni finestra

            Controls.Add(btnCucina); // Aggiunge btnCucina
            Controls.Add(btnCompra); // Aggiunge btnCompra
            Controls.Add(textSpesa); // Aggiunge textSpesa
            Controls.Add(textRicetta); // Aggiunge textRicetta
            Controls.Add(textDispensa); // Aggiunge textDispensa
            Controls.Add(textOrdine); // Aggiunge textOrdine
            Controls.Add(label4); // Aggiunge label4
            Controls.Add(label3); // Aggiunge label3
            Controls.Add(label2); // Aggiunge label2
            Controls.Add(label1); // Aggiunge label1

            Margin = new Padding(3, 4, 3, 4); // Margini finestra

            Name = "Form1"; // Nome della finestra
            Text = "Form1"; // Titolo finestra

            Load += Form1_Load; // Evento caricamento finestra

            ResumeLayout(false); // Riattiva il layout
            PerformLayout(); // Aggiorna il layout
        }

        #endregion

        private Label label1; // Dichiarazione label1
        private Label label2; // Dichiarazione label2
        private Label label3; // Dichiarazione label3
        private Label label4; // Dichiarazione label4

        private TextBox textOrdine; // Dichiarazione textbox ordine
        private TextBox textDispensa; // Dichiarazione textbox dispensa
        private TextBox textRicetta; // Dichiarazione textbox ricetta
        private TextBox textSpesa; // Dichiarazione textbox spesa

        private Button btnCompra; // Dichiarazione pulsante compra
        private Button btnCucina; // Dichiarazione pulsante cucina
    }
}